var config = {
    map: {
        '*': {
            apparelowlcarousel: 'Hidden_Apparel/js/owl.carousel',
        }
    }
};